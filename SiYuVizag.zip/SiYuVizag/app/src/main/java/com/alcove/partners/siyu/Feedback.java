/*
Updated by Sirisha Balireddy on 25-04-2019 - SiYuVizag 1.1
 */
package com.alcove.partners.siyu;

import android.os.Handler;
import android.os.Bundle;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;

public class Feedback extends second {
    EditText edit, edit1;
    // String datas,data;
    DbHelper dbhelper = new DbHelper(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadLocale();
        setContentView(R.layout.activity_feedback);
        edit = (EditText) findViewById(R.id.ed1);
        edit1 = (EditText) findViewById(R.id.ed2);
        Intent i1 = getIntent();


    }
    //Inserting the data into database taken from the inputs of users

    public void gotoDatabase(View view) {
        String set1 = edit.getText().toString();
        String set2 = edit1.getText().toString();
        if (set1.equals("") || set2.equals("")) {
            Toast.makeText(getApplicationContext(), "Please fill in all details", Toast.LENGTH_SHORT).show();
        } else {
            SQLiteDatabase sqLiteDatabase = dbhelper.getWritableDatabase();
            ContentValues Names = new ContentValues();
            ContentValues Names1 = new ContentValues();
            Names1.put("Name", set1);
            Names.put("Feedback", set2);
            sqLiteDatabase.insert("Feedback", null, Names);
            sqLiteDatabase.insert("Feedback", null, Names1);
            sqLiteDatabase.close();
            dbhelper.close();
            Toast.makeText(getApplicationContext(), "Thank you for your feedback.", Toast.LENGTH_SHORT).show();
            gotoHome();
        }

    }

//This function is to go back to the previous activity
    public void gotoHome() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                Intent gotoScreenVar = new Intent(Feedback.this, second.class);
                gotoScreenVar.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(gotoScreenVar);
            }
        }, 1000);


    }
}

