/*
Updated and Modified by Sirisha Balireddy -14-05-2019 -SiYuVizag 1.1
 */
package com.alcove.partners.siyu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class FoodActivity extends second  implements  AdapterView.OnItemClickListener {
   //Takes the values in form of strings
    String[] hnames = {"Flying Spaghetti Monster","Mint Garden","Kamat Restaurant","Barbeque Nation","SriSaiRam Parlour", "Dharani Restaurant","Tycoon MultiCuisine Restaurant", "Green Park","Shack","Venkatadri Vantillu",
            "The Eatery","FoodEx","Welcom Cafe Oceanic Restaurant"};

    ListView lv;
    ArrayList<String> listItem =new ArrayList<String>();
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadLocale();
        setContentView(R.layout.activity_food);
        //Adding elements to the arraylist
        listItem = new ArrayList<>();
        for (int i = 0; i < hnames.length; i++) {
            listItem.add(hnames[i]);
        }
        //Sorts the arraylist and array
        Collections.sort(listItem);
        Arrays.sort(hnames);
        lv = (ListView) findViewById(R.id.lv4);
        lv.setOnItemClickListener(this);
        //setting the arraylist to listview
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listItem);
        lv.setAdapter(ad);


    }
//Deals with function to be performed when a particular item is clicked
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Intent i1=new Intent(FoodActivity.this,food.class);
        i1.putExtra("restaurantnames", hnames[i]);
        startActivity(i1);

    }
   /*
   This section inserts the data into the SqLite Database
    */

    public void gotoPrevious(View view){

        Intent i = new Intent(this,second.class);
        startActivity(i);
    }
}
