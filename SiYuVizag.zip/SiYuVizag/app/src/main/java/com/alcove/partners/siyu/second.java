/*
Updated and modified by Sirisha Balireddy -25-04-2019 - SiYuVizag 1.1
 */
/*
This module deals with the second page of application where it provides users with some options like hotels,food or restaurants
busfares,emergency contacts, places to visit and feed back.
 */
package com.alcove.partners.siyu;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.Locale;

public class second extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
     loadLocale();
       setContentView(R.layout.activity_second);
        Button b1=(Button)findViewById(R.id.b1);
       b1.setOnClickListener(new View.OnClickListener() {
         @Override
           public void onClick(View v) {
             showChangeLanguageDialog();
           }
       });


    }
    //This creates the spinner where the user will be able to select the language he/she wants to
   public void showChangeLanguageDialog()
    {
        final String[] listItems={"English","हिंदी","తెలుగు","বাঙালি","ନୀୟ"};
        AlertDialog.Builder nBuilder =new AlertDialog.Builder(second.this);
        nBuilder.setTitle("Choose Language");
        nBuilder.setSingleChoiceItems(listItems, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if(i==0)
                {
                    setLocale("en");
                    recreate();
                }
                else if(i==1)
                {
                    setLocale("hi");
                    recreate();
                }
                else if(i==2)
                {
                    setLocale("te");
                    recreate();
                }
               else  if(i==3)
                {
                    setLocale("bn");
                    recreate();
                }
                else if(i==4)
                {
                    setLocale("or");
                    recreate();
                }
                dialogInterface.dismiss();
            }
        });

        AlertDialog mDialog = nBuilder.create();
        mDialog.show();
    }
//this function sets the the lanuage from default language
    public void setLocale(String lang)
    {
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale=locale;
        getBaseContext().getResources().updateConfiguration(config,getBaseContext().getResources().getDisplayMetrics());
        SharedPreferences.Editor editor =getSharedPreferences("Settings",MODE_PRIVATE).edit();
        editor.putString("MyLanguage",lang);
        editor.apply();

    }
    //This change the language
    public void loadLocale()
    {
        SharedPreferences pref = getSharedPreferences("Settings",MODE_PRIVATE);
        String language =pref.getString("MyLanguage","");
        setLocale(language);
    }
        public void busFare (View view){
            Intent i = new Intent(this, busFare.class);
            startActivity(i);
        }
        public void restRoom (View view){
            Intent i = new Intent(this, rest.class);
            startActivity(i);
        }
        public void emergency (View view){
            Intent i = new Intent(this, Emergency.class);
            startActivity(i);
        }
        public void places (View view){
            Intent i = new Intent(this, PlacesActivity.class);
            startActivity(i);
        }
        public void food (View view){
            Intent i = new Intent(this, FoodActivity.class);
            startActivity(i);
        }
        public void feedback (View view){
            Intent i = new Intent(this, Feedback.class);
            startActivity(i);
        }
        public void gotoPrevious (View view){

            Intent i = new Intent(this, second.class);
            startActivity(i);
        }


   /* boolean doubleBackToExitPressedOnce = false;
//This function takes care of when the user presses the back button in his mobile.
    @Override
    public void onBackPressed() {

        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();


        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }*/
}

